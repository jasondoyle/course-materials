/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/* unused harmony exports getObjectFromLocalStorage, saveObjectInChromeSyncStorage, getCxtUserFromCache */
const getCxtUserFromCache = async function () {
  var CXT_USER = await getStorageValuePromise()

  // validate all data
  for (const key in CXT_USER) {
    // eslint-disable-next-line no-prototype-builtins
    if (CXT_USER.hasOwnProperty(key)) {
      if (key == null) CXT_USER = null
    }
  }
  return CXT_USER
}

function getStorageValuePromise() {
  return new Promise((resolve) => {
    // eslint-disable-next-line no-undef
    chrome.storage.sync.get(
      [
        'verified',
        'userId',
        'username',
        'email',
        'eth_wallet',
        'CEXT_UID',
        'plan',
        'accessToken',
        'usersGroups',
      ],
      resolve
    )
  })
}

/**
 * Retrieve object from Chrome's Local StorageArea
 * @param {string} key
 */
const getObjectFromLocalStorage = async function (key) {
  return new Promise((resolve, reject) => {
    try {
      // eslint-disable-next-line no-undef
      chrome.storage.sync.get(key, function (value) {
        resolve(value[key])
      })
    } catch (ex) {
      reject(ex)
    }
  })
}

/**
 * Save Object in Chrome's Local StorageArea
 * @param {*} obj
 */
const saveObjectInChromeSyncStorage = async function (obj) {
  return new Promise((resolve, reject) => {
    try {
      // eslint-disable-next-line no-undef
      chrome.storage.sync.set(obj, function () {
        resolve()
      })
    } catch (ex) {
      reject(ex)
    }
  })
}



/******/ })()
;
//# sourceMappingURL=cxt_userlib.js.map