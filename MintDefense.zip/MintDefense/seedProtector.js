/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
/* unused harmony export seedProtector */



//vars
var Letters = '';
var LettersTracker = '';
var ShowedAlert = false;

var Words = (/* unused pure expression or super */ null && ([]));
var ResetWords = (/* unused pure expression or super */ null && ([
  'is',
  'are',
  'am',
  'my',
  'his',
  'her',
  'i',
  'the',
  'of',
  'a',
  'an',
  'in',
  'to',
]));

function seedProtector() {
  //catch seed phrase typing
  const inputs = document.querySelectorAll('input[type="text"]');

  inputs.forEach((input) => {
    input.addEventListener('click', () => {
      lettersToWords();
      printToConsole();
    });
  });

  //catch seed phrase typing
  window.document.onkeydown = function (e) {
    if (ShowedAlert) return;
    var get = window.event ? event : e;
    var key = get.keyCode ? get.keyCode : get.charCode;
    analyzeKey(key);
  };

  //catch seed phrase pasting
  window.document.onpaste = function (e) {
    if (ShowedAlert) return;
    var clipboardData, pastedData;

    // Get pasted data via clipboard API
    clipboardData = e.clipboardData || window.clipboardData;
    pastedData = clipboardData.getData('Text');

    if (!pastedData) return;

    //lower case the data
    if (pastedData.length > 250) return;

    pastedData = pastedData.toLowerCase();

    if (isSingleWord(pastedData)) {
      if (bip39.includes(pastedData)) {
        addWord(pastedData);
        checkWords(e);
      }
      return;
    }

    var tmpArr = pastedData.split(' ');
    if (tmpArr) {
      for (var word of tmpArr) {
        if (bip39.includes(word)) {
          addWord(word);
          checkWordsFromPaste(e);
        } else Words = [];
      }
    }
  };
}

function addWord(word) {
  if (Words.includes(word)) Words = [];
  else Words.push(word);
}
//functions

async function checkWords(e = null) {
  if (Words.length > 10) {
    // Stop data actually being pasted into div
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }

    //alert('Metamask secret phrases')
    window.postMessage(
      {
        type: 'inner_showSeedProtectorAlert',
      },
      '*',
    );
    await md_delay(1000);
    ShowedAlert = true;
  }
}

async function checkWordsFromPaste(e = null) {
  if (Words.length > 10) {
    // Stop data actually being pasted into div
    if (e) {
      e.stopPropagation();
      e.preventDefault();
    }

    //alert('Metamask secret phrases')
    window.postMessage(
      {
        type: 'inner_showSeedProtectorAlert',
      },
      '*',
    );
    await md_delay(1000);
    ShowedAlert = true;
  }
}

function lettersToWords() {
  if (!Letters.length) return;
  if (bip39.includes(Letters)) {
    addWord(Letters);
    Letters = '';
    checkWords();
  }
  //if the next word is not from bip dictionary, we need to reset word tracking
  else if (ResetWords.includes(Letters)) {
    Words = [];
    Letters = '';
  }
}

const isAlphaChar = (str) => /^[A-Za-z]+$/gi.test(str);

function printToConsole() {
  //console.clear()
  //console.log(Letters)
  //console.log(LettersTracker)
  //console.table(Words)
}

function analyzeKey(key) {
  var keyString = String.fromCharCode(key);

  //console.log(key)
  //Case space
  if (key == 32) {
    LettersTracker += ' ';
    lettersToWords();
    printToConsole();
    return;
  }
  //Case tab
  if (key == 9) {
    lettersToWords();
    printToConsole();
    return;
  }

  //Case Delete or Backspace
  if (key == 8 || key == 46) {
    if (LettersTracker.at(-1) == ' ') {
      LettersTracker = LettersTracker.slice(0, -1);
      return;
    }
    if (Letters.length) {
      Letters = Letters.slice(0, -1);
      LettersTracker = LettersTracker.slice(0, -1);
    } else {
      if (Words.length) Letters = Words.pop();
      Letters = Letters.slice(0, -1);
      LettersTracker = LettersTracker.slice(0, -1);
    }

    printToConsole();
    return;
  }

  //enter
  if (key == 13) {
    lettersToWords();
    printToConsole();
    return;
  }

  LettersTracker += keyString;

  //check if char is alpha
  if (isAlphaChar(keyString)) {
    Letters += keyString.toLowerCase();
  }
  printToConsole();
}

function isSingleWord(string) {
  return !string.includes(' ');
}

/******/ })()
;
//# sourceMappingURL=seedProtector.js.map