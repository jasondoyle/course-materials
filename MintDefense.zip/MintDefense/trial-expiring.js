/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
setTimeout(() => {
    const search = location.search.substring(1).replace('payload=', '');

    const payload = JSON.parse(atob(search));

    $('#trial-days-remaining').text(`${payload.days} day${payload.days > 1 ? 's': ''}`) 
    $('#trial-expiring-info').html(`On ${new Intl.DateTimeFormat('en', { dateStyle: 'full', timeStyle: 'short'}).format(
        new Date(payload.expiresAt)
    )}, your trial access to MintDefense will end. If you
    activated this trial as part of a discounted offer, the discount
    will also expire. To avoid losing access, purchase a license
    <a href="${payload.url}" target="_blank" rel="noopener noreferrer">here</a>.`.replace('\n,', ' '))
}, 100)
/******/ })()
;
//# sourceMappingURL=trial-expiring.js.map