/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
var __webpack_exports__ = {};

;// CONCATENATED MODULE: ./src/shared/constants/settings.js
const SETTINGS = {
  ExcludedDomains: [
    '*://*.etherscan.io/*',
    '*://*.bscscan.com/*',
    '*://*.arbiscan.io/*',
    '*://*.polygonscan.com/*',
    '*://*.snowtrace.io/*',
    '*://*.ftmscan.com/*',
    '*://*.moonscan.io/*',
    '*://*.mintdefense.com/*',
    '*://*.google.com/*',
    '*://localhost/*',
    '*://127.0.0.1/*',
  ],
  openTranslators: [],
  translatorURI: 'https://app-dev.mintdefense.com/translator',
  showedDisconnect: false,
  MD_DOMAIN: "mintdefense.com",
  CONTROL_PANEL_URL: "https://app.mintdefense.com",
  DEV:
     false
      ? 0
      : false,
  MIXPANEL_PROJ_TOKEN: "b9d96416122f976492297ffed418d6c3",
  defaultSettings: {
    showInitLoader: true,
    notifications: true,
    simulate: false,
    maskBalance: false,
    maskBalanceAddr: '',
    mevProtection: false,
    protectEverywhere: true,
  },
};

;// CONCATENATED MODULE: ./src/js/message.js

/* eslint-disable no-undef */
// Function Declarations
const getMessageDataFromUrl = (searchString) => {
  const rawString = searchString.slice(1); // Equivalent to substring(1)
  try {
    let decodedString = decodeURIComponent(rawString);
    decodedString = decodedString.replace(/=$/, '');
    // Replace '+' with space (' ')
    decodedString = decodedString.replace(/\+/g, ' ');

    return JSON.parse(decodedString);
  } catch (error) {
    console.error('Error parsing JSON string:', error);
    return null;
  }
};

const convertTemplateToHtml = (templateString) => {
  let htmlElements = [];
  let currentIndex = 0;

  while (currentIndex < templateString.length) {
    const nextLinkIndex = templateString.indexOf('{{link}}', currentIndex);
    const nextNewLineIndex = templateString.indexOf('{{nl}}', currentIndex);
    const nextImageIndex = templateString.indexOf('{{img}}', currentIndex);

    const nextTagIndex = Math.min(
      nextLinkIndex !== -1 ? nextLinkIndex : Infinity,
      nextNewLineIndex !== -1 ? nextNewLineIndex : Infinity,
      nextImageIndex !== -1 ? nextImageIndex : Infinity,
    );

    if (nextTagIndex === Infinity) {
      htmlElements.push(templateString.slice(currentIndex));
      break;
    }

    htmlElements.push(templateString.slice(currentIndex, nextTagIndex));

    if (nextTagIndex === nextLinkIndex) {
      const linkRegex = /{{link}}(.*?)\[(.*?)\]/;
      const linkMatch = templateString.slice(nextTagIndex).match(linkRegex);
      if (linkMatch) {
        const [, linkText, linkUrl] = linkMatch;
        const anchorElement = `<a href="${linkUrl}" target="_blank" class="generatedLink"; style="color: #ffca00; text-decoration: underline; cursor: pointer;">${linkText}</a>`;
        htmlElements.push(anchorElement);
        currentIndex = nextTagIndex + linkMatch[0].length;
      }
    } else if (nextTagIndex === nextNewLineIndex) {
      htmlElements.push('<br>');
      currentIndex = nextTagIndex + '{{nl}}'.length;
    } else if (nextTagIndex === nextImageIndex) {
      const imgRegex = /{{img}}\[(.*?)\]/;
      const imgMatch = templateString.slice(nextTagIndex).match(imgRegex);
      if (imgMatch) {
        const imgUrl = imgMatch[1];
        const imgElement = `<img src="${imgUrl}" alt="Dynamic Image" style="height: auto; width: 50%; object-fit: contain; position: relative; padding-top: 10px; padding-bottom: 10px;">`;
        htmlElements.push(imgElement);
        currentIndex = nextTagIndex + imgMatch[0].length;
      }
    }
  }

  return htmlElements.join('');
};

const getReadableDate = (dateString) => {
  const date = new Date(dateString);

  const year = date.getFullYear().toString().slice(-2); // Get last 2 digits of year
  const month = (date.getMonth() + 1).toString().padStart(2, '0'); // Add 1 as months are 0-indexed
  const day = date.getDate().toString().padStart(2, '0');
  //const hour = date.getHours().toString().padStart(2, '0');
  //const minute = date.getMinutes().toString().padStart(2, '0');

  //return `${month}/${day}/${year}-${hour}:${minute}`;
  return `${month}/${day}/${year}`;
};

const loadMessageData = () => {
  //get message data from url params, decode it, and convert to HTML
  const currentLocation = window.location;
  const messageDataArray = getMessageDataFromUrl(
    currentLocation.search,
  ).messages; // This should return an array of messages

  if (messageDataArray && messageDataArray.length > 0) {
    // Process each message and store the resulting HTML
    const htmlMessages = messageDataArray.map((messageData, index) => {
      const html = convertTemplateToHtml(messageData?.data?.message);
      return `<div class="carousel-item ${index === 0 ? 'active' : ''}">
              <div class="message-date">${
                getReadableDate(messageData.createdAt) ?? ''
              }</div>${html}
              </div>`;
    });

    // Insert messages into the carousel
    const carouselInner = document.querySelector('.message-container-wrapper');
    carouselInner.innerHTML = htmlMessages.join('');

    const carouselTitle = document.querySelector('.generatedLink');
    carouselTitle.href = `${SETTINGS.CONTROL_PANEL_URL}/dashboard/messages/`;
  } else {
    // Handle case where no message data is available
    console.error('No message data available');
  }
};

// Main Execution
loadMessageData();

$(document).ready(() => {
  $('.messages-button').click(async () => {
    window.open(`${SETTINGS.CONTROL_PANEL_URL}/dashboard/messages/`, '_blank');
    window.close();
  });

  //close the message popup if any link has been clicked
  $('.generatedLink').click(async () => {
    window.close();
  });
});

/******/ })()
;
//# sourceMappingURL=message.js.map