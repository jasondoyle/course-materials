/* eslint-disable no-undef */
// Change Title on slide
$('.MD_twitterShareBtn').click(async (e) => {
  const elementId = e.target.id;
  alert(elementId);
  e.preventDefault();
  console.log('new message alert type', elementId);
  postMessage({ type: 'alertTwitterShare', alert: elementId }, '*');
});

$('.MD_close').click(async () => {
  // Select the element you want to remove
  const elementToRemove = document.getElementById('MintDefensePopup'); // Replace 'elementId' with the actual ID

  // Remove the element
  if (elementToRemove) {
    elementToRemove.remove();
  }
});

// Change Title on slide
$('#carouselMessage').on('slide.bs.carousel', function (e) {
  try {
    //hide all content but show selected
    const forSlide = $('.for-slide-' + $(e.relatedTarget).index());
    if (!forSlide.hasClass('show')) {
      $('[class*="for-slide-"]').each(function () {
        $(this).collapse('hide'); // Hide elements
      });
      forSlide.collapse('show');
    }
    //hide all content titles but show selected title
    const forSlideTitle = $('.for-slide-title-' + $(e.relatedTarget).index());
    if (!forSlideTitle.hasClass('show')) {
      $('[class*="for-slide-title-"]').each(function () {
        $(this).collapse('hide'); // Hide elements
      });
      forSlideTitle.collapse('show');
    }
  } catch (error) {
    console.error(error);
  }
});
